package Cofre;

public class Dolar extends Moeda {
    public Dolar(double valor) {
        super(valor, "Dolar");
    }

    @Override
    public double converterParaReal() {
        
        return getValor() * 5.49; //Valor atual da moeda
    }
}