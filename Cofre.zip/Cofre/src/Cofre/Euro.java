package Cofre;

public class Euro extends Moeda {
    public Euro(double valor) {
        super(valor, "Euro");
    }

    @Override
    public double converterParaReal() {
        
        return getValor() * 5.75; // Valor atual da moeda
    }
}